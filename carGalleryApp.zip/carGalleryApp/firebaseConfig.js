// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";
import { getStorage } from "firebase/storage"; // Firebase Storage ekleniyor

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCpkv0tk0YXuYBIZ_MjtajKfoK_bS9J954",
  authDomain: "cargalleryapp.firebaseapp.com",
  projectId: "cargalleryapp",
  storageBucket: "cargalleryapp.appspot.com",
  messagingSenderId: "447040810071",
  appId: "1:447040810071:web:9d18003e13b183fd368712",
  measurementId: "G-0KTBH9R1JY",
  databaseURL: "https://cargalleryapp-default-rtdb.firebaseio.com", // Realtime Database URL
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);
const firebaseStorage = getStorage(app); // Değişiklik yapıldı

export { app, auth, database, firebaseStorage }; // Storage'u da export ediyoruz

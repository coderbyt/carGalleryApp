import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CarListScreen from './screens/CarListScreen';
import CarDetailScreen from './screens/CarDetailScreen';
import AddCarScreen from './screens/AddCarScreen';
import LoginScreen from './screens/LoginScreen';
import SignupScreen from './screens/SignupScreen';
import ProfileScreen from './screens/ProfileScreen'; 


const Stack = createStackNavigator();

export default function App() {
  const [initialRoute, setInitialRoute] = useState('Login');

  useEffect(() => {
    const checkToken = async () => {
      const token = await AsyncStorage.getItem('userToken');
      if (token) {
        setInitialRoute('CarList');
      }
    };
    checkToken();
  }, []);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={initialRoute}>
        <Stack.Screen 
          name="Login" 
          component={LoginScreen} 
          options={{ title: 'Giriş Yap' }} 
        />
        <Stack.Screen 
          name="CarList" 
          component={CarListScreen} 
          options={{ title: 'Araçlar' }} 
        />
        <Stack.Screen 
          name="CarDetail" 
          component={CarDetailScreen} 
          options={({ route }) => ({ title: `${route.params.car.brand} ${route.params.car.model}` })} 
        />
        <Stack.Screen 
          name="AddCar" 
          component={AddCarScreen} 
          options={{ title: 'Araç Ekle' }} 
        />
        <Stack.Screen 
          name="Signup" 
          component={SignupScreen} 
          options={{ title: 'Kaydol' }} 
        />
        <Stack.Screen 
          name="Profile" 
          component={ProfileScreen} 
          options={{ title: 'Profilim' }} 
        />
      
      </Stack.Navigator>
    </NavigationContainer>
  );
}

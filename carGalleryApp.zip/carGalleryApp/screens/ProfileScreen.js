import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { auth } from '../firebaseConfig';

export default function ProfileScreen() {
  const [email, setEmail] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [image, setImage] = useState(null);

  useEffect(() => {
    const fetchUserData = async () => {
      const currentUser = auth.currentUser;
      if (currentUser) {
        setEmail(currentUser.email);
      }
    };

    if (auth) {
      fetchUserData();
    }
  }, []);

  const handleChangePassword = async () => {
    try {
      if (!currentPassword || !newPassword) {
        Alert.alert('Şifre Alanı Boş', 'Lütfen mevcut ve yeni bir şifre girin.');
        return;
      }
  
      const currentUser = auth.currentUser;
  
      if (!currentUser) {
        console.error('Kullanıcı bulunamadı.');
        return;
      }
  
      const credential = firebase.auth.EmailAuthProvider.credential(currentUser.email, currentPassword);
      await currentUser.reauthenticateWithCredential(credential);
      await currentUser.updatePassword(newPassword);
      Alert.alert('Başarılı', 'Şifre başarıyla güncellendi.');
      setCurrentPassword('');
      setNewPassword('');
    } catch (error) {
      console.error('Şifre güncelleme hatası:', error.message);
      Alert.alert('Hata', 'Şifre güncellenirken bir hata oluştu. Lütfen tekrar deneyin.');
    }
  };
  

  const handleSelectImage = async () => {
    let result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.top}>
        <Ionicons name="person-circle-outline" size={100} color="#333" style={styles.profileIcon} />
        <TouchableOpacity onPress={handleSelectImage}>
          <Text style={styles.changePhoto}>Profil Fotoğrafını Değiştir</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.form}>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>E-posta:</Text>
          <TextInput
            style={styles.input}
            value={email}
            placeholder="E-posta adresiniz"
            placeholderTextColor="#777"
            keyboardType="email-address"
            autoCapitalize="none"
            editable={false}
          />
        </View>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Mevcut Şifre:</Text>
          <TextInput
            style={styles.input}
            value={currentPassword}
            onChangeText={setCurrentPassword}
            placeholder="Mevcut şifrenizi girin"
            placeholderTextColor="#777"
            secureTextEntry
          />
        </View>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Yeni Şifre:</Text>
          <TextInput
            style={styles.input}
            value={newPassword}
            onChangeText={setNewPassword}
            placeholder="Yeni şifrenizi girin"
            placeholderTextColor="#777"
            secureTextEntry
          />
        </View>
        <TouchableOpacity onPress={handleChangePassword} style={styles.saveButton}>
          <Text style={styles.saveButtonText}>Şifreyi Değiştir</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    paddingTop: 20,
  },
  top: {
    alignItems: 'center',
  },
  profileIcon: {
    marginBottom: 20,
  },
  changePhoto: {
    color: '#007AFF',
    fontSize: 16,
  },
  form: {
    width: '80%',
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
    marginBottom: 5,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    fontSize: 16,
    borderRadius: 5,
    color: '#333',
  },
  saveButton: {
    backgroundColor: '#0095B6',
    paddingVertical: 15,
    borderRadius: 5,
    marginTop: 20,
  },
  saveButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

import React, { useState, useEffect } from 'react';
import { View, FlatList, StyleSheet, TouchableOpacity, Text, Alert } from 'react-native';
import CarItem from '../components/CarItem';
import Ionicons from '@expo/vector-icons/Ionicons';
import { getAuth, signOut } from "firebase/auth";
import { ref, onValue } from 'firebase/database';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { database } from '../firebaseConfig';

export default function CarListScreen({ navigation, route }) {
  const [cars, setCars] = useState([]);
  const [menuVisible, setMenuVisible] = useState(false);

  useEffect(() => {
    const loadCars = () => {
      const carsRef = ref(database, 'cars');

      onValue(carsRef, (snapshot) => {
        const data = snapshot.val();

        if (data) {
          const carList = Object.entries(data).map(([id, car]) => ({ id, ...car }));
          console.log('Loaded cars:', carList); // Debugging log
          setCars(carList);
        } else {
          setCars([]);
        }
      });
    };

    loadCars();
  }, []);

  useEffect(() => {
    if (route.params && route.params.updatedCar) {
      const updatedCar = route.params.updatedCar;
      setCars((prevCars) =>
        prevCars.map((car) =>
          car.id === updatedCar.id ? updatedCar : car
        )
      );
    }
  }, [route.params]);

  const navigateToAddCar = () => {
    navigation.navigate('AddCar');
  };

  const handleLogout = async () => {
    try {
      const auth = getAuth();
      await signOut(auth);
      await AsyncStorage.removeItem('userToken');
      await AsyncStorage.removeItem('email');
      await AsyncStorage.removeItem('password');
      console.log("Kullanıcı başarıyla çıkış yaptı.");
      navigation.navigate('Login', { resetFields: true });
    } catch (error) {
      console.error("Çıkış yapma hatası:", error);
      Alert.alert("Çıkış Yapma Hatası", "Çıkış yapılırken bir hata oluştu. Lütfen tekrar deneyin.");
    }
  };

  const toggleMenu = () => {
    setMenuVisible(!menuVisible);
  };

  const goToProfile = () => {
    setMenuVisible(false);
    navigation.navigate('Profile');
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={cars}
        renderItem={({ item }) => (
          <CarItem
            car={item}
            onPress={() => navigation.navigate('CarDetail', { car: item })}
          />
        )}
        keyExtractor={(item, index) => index.toString()}
      />
      {menuVisible && (
        <View style={styles.menu}>
          <TouchableOpacity style={styles.menuItem} onPress={goToProfile}>
            <Ionicons name="person-circle-outline" size={20} color="#007AFF" />
            <Text style={styles.menuText}>Profilim</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuItem} onPress={handleLogout}>
            <Ionicons name="log-out-outline" size={20} color="#007AFF" />
            <Text style={styles.menuText}>Çıkış Yap</Text>
          </TouchableOpacity>
        </View>
      )}
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.addButton} onPress={navigateToAddCar}>
          <Text style={styles.addButtonText}>+ Araç Ekle</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuButton} onPress={toggleMenu}>
          <Text style={styles.menuButtonText}>Menü</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f7f9fc',
    position: 'relative',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  addButton: {
    flex: 1,
    backgroundColor: 'transparent',
    padding: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'green',
    alignItems: 'center',
    marginRight: 10,
  },
  addButtonText: {
    color: 'green',
    fontSize: 16,
  },
  menuButton: {
    flex: 1,
    backgroundColor: 'transparent',
    padding: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'brown',
    alignItems: 'center',
    marginLeft: 10,
  },
  menuButtonText: {
    color: 'brown',
    fontSize: 16,
  },
  menu: {
    position: 'absolute',
    bottom: 70,
    right: 20,
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 5,
    zIndex: 3,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  menuText: {
    marginLeft: 10,
    fontSize: 16,
    color: '#007AFF',
  },
});

import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { database } from '../firebaseConfig'; // Firebase yapılandırma dosyasını içe aktarın
import { ref, push } from 'firebase/database';

export default function AddCarScreen({ navigation }) {
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [year, setYear] = useState('');
  const [price, setPrice] = useState('');
  const [info, setInfo] = useState('');
  const [mileage, setMileage] = useState('');
  const [accidentHistory, setAccidentHistory] = useState('');
  const [lastExpertiseDate, setLastExpertiseDate] = useState('');
  const [plateNumber, setPlateNumber] = useState('');
  const [errors, setErrors] = useState({});

  const validate = () => {
    let valid = true;
    let errors = {};

    if (brand.trim() === '') {
      errors.brand = 'Marka gerekli';
      valid = false;
    }
    if (model.trim() === '') {
      errors.model = 'Model gerekli';
      valid = false;
    }
    if (year.trim() === '' || isNaN(year) || parseInt(year) < 1886 || parseInt(year) > new Date().getFullYear()) {
      errors.year = 'Geçerli bir yıl girin (1886 - günümüz)';
      valid = false;
    }
    if (price.trim() === '' || isNaN(price) || parseFloat(price) <= 0) {
      errors.price = 'Geçerli bir fiyat girin';
      valid = false;
    }
    if (info.trim() === '') {
      errors.info = 'Bilgi gerekli';
      valid = false;
    }
    if (mileage.trim() === '' || isNaN(mileage) || parseInt(mileage) < 0) {
      errors.mileage = 'Geçerli bir kilometre durumu girin';
      valid = false;
    }
    if (accidentHistory.trim() === '') {
      errors.accidentHistory = 'Kaza geçmişi gerekli';
      valid = false;
    }
    if (lastExpertiseDate.trim() === '' || !/^\d{4}-\d{2}-\d{2}$/.test(lastExpertiseDate)) {
      errors.lastExpertiseDate = 'Geçerli bir tarih girin (YYYY-MM-DD)';
      valid = false;
    }
    const plateNumberRegex = /^(0[1-9]|[1-7][0-9]|8[0-1])[A-Z]{1,3}\d{1,4}$/;
    if (plateNumber.trim() === '' || !plateNumberRegex.test(plateNumber)) {
      errors.plateNumber = 'Geçerli bir plaka girin (örn: 34ABC1234)';
      valid = false;
    }

    setErrors(errors);
    return valid;
  };

  const handleSubmit = async () => {
    if (validate()) {
      const newCar = {
        brand: brand,
        model: model,
        year: year,
        price: price,
        info: info,
        mileage: mileage,
        accidentHistory: accidentHistory,
        lastExpertiseDate: lastExpertiseDate,
        plateNumber: plateNumber
      };

      try {
        await push(ref(database, 'cars'), newCar); // Firebase'e yeni araç ekle
        navigation.navigate('CarList', { newCar: newCar }); // Yeni aracı CarList'e gönder
      } catch (error) {
        console.error("Veri eklenirken bir hata oluştu:", error);
      }
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.label}>Marka:</Text>
      <TextInput
        style={styles.input}
        value={brand}
        onChangeText={setBrand}
      />
      {errors.brand && <Text style={styles.error}>{errors.brand}</Text>}

      <Text style={styles.label}>Model:</Text>
      <TextInput
        style={styles.input}
        value={model}
        onChangeText={setModel}
      />
      {errors.model && <Text style={styles.error}>{errors.model}</Text>}

      <Text style={styles.label}>Yıl:</Text>
      <TextInput
        style={styles.input}
        value={year}
        onChangeText={setYear}
        keyboardType="numeric"
      />
      {errors.year && <Text style={styles.error}>{errors.year}</Text>}

      <Text style={styles.label}>Fiyat:</Text>
      <TextInput
        style={styles.input}
        value={price}
        onChangeText={setPrice}
        keyboardType="numeric"
      />
      {errors.price && <Text style={styles.error}>{errors.price}</Text>}

      <Text style={styles.label}>Bilgi:</Text>
      <TextInput
        style={styles.input}
        value={info}
        onChangeText={setInfo}
      />
      {errors.info && <Text style={styles.error}>{errors.info}</Text>}

      <Text style={styles.label}>Kilometre Durumu:</Text>
      <TextInput
        style={styles.input}
        value={mileage}
        onChangeText={setMileage}
        keyboardType="numeric"
      />
      {errors.mileage && <Text style={styles.error}>{errors.mileage}</Text>}

      <Text style={styles.label}>Kaza Geçmişi:</Text>
      <TextInput
        style={styles.input}
        value={accidentHistory}
        onChangeText={setAccidentHistory}
      />
      {errors.accidentHistory && <Text style={styles.error}>{errors.accidentHistory}</Text>}

      <Text style={styles.label}>En Son Muayene Tarihi:</Text>
      <TextInput
        style={styles.input}
        value={lastExpertiseDate}
        onChangeText={setLastExpertiseDate}
        placeholder="YYYY-MM-DD"
      />
      {errors.lastExpertiseDate && <Text style={styles.error}>{errors.lastExpertiseDate}</Text>}

      <Text style={styles.label}>Plaka:</Text>
      <TextInput
        style={styles.input}
        value={plateNumber}
        onChangeText={setPlateNumber}
      />
      {errors.plateNumber && <Text style={styles.error}>{errors.plateNumber}</Text>}

      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Ekle</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    fontSize: 16,
    borderRadius: 5,
    marginTop: 10,
  },
  error: {
    color: 'red',
    marginTop: 5,
  },
  button: {
    backgroundColor: '#0095B6',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
});

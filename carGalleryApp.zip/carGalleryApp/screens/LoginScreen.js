import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground, Alert } from 'react-native';
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import AsyncStorage from '@react-native-async-storage/async-storage';
import app from '../firebaseConfig';

export default function LoginScreen({ navigation, route }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    // AsyncStorage'da token olup olmadığını kontrol edin
    const checkUserToken = async () => {
      const userToken = await AsyncStorage.getItem('userToken');
      if (userToken) {
        navigation.navigate('CarList');
      }
    };
    checkUserToken();

    // Eğer route.params.resetFields true ise giriş bilgilerini sıfırla
    if (route.params && route.params.resetFields) {
      setEmail('');
      setPassword('');
      AsyncStorage.removeItem('email');
      AsyncStorage.removeItem('password');
    }
  }, [route.params]);

  const handleLogin = async () => {
    try {
      const auth = getAuth();
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      console.log("Oturum açan kullanıcı:", user);

      // Token'ı AsyncStorage'a kaydedin
      await AsyncStorage.setItem('userToken', user.accessToken);
      await AsyncStorage.setItem('email', email);
      await AsyncStorage.setItem('password', password);

      navigation.navigate('CarList');
    } catch (error) {
      console.error("Oturum açma hatası:", error);
      Alert.alert("Oturum Açma Hatası", "Giriş yapılırken bir hata oluştu. Lütfen tekrar deneyin.");
    }
  };

  const handleGuestLogin = () => {
    navigation.navigate('CarList');
  };

  return (
    <ImageBackground
      source={{ uri: 'https://downloadwap.com/thumbs2/wallpapers/p2ls/2019/cars-transport/43/3af8242c13695363.jpg' }}
      style={styles.backgroundImage}
    >
      <View style={styles.container}>
        <View style={styles.form}>
          <Text style={styles.title}>Hoş Geldiniz 🙃</Text>
          <View style={styles.line}></View>
          <Text style={styles.label}>Email:</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="Email adresinizi girin"
            placeholderTextColor="#777"
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <Text style={styles.label}>Şifre:</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            placeholder="Şifrenizi girin"
            placeholderTextColor="#777"
            secureTextEntry
          />
          <TouchableOpacity onPress={handleLogin} style={styles.button}>
            <Text style={styles.buttonText}>Giriş Yap</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
            <Text style={styles.link}>Hesabınız yok mu? Kaydolun</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  form: {
    backgroundColor: 'rgba(0, 0, 0, 0.0)',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 10,
    textAlign: 'center',
    marginBottom: 10,
  },
  line: {
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
    marginBottom: 10,
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
    color: 'white',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    fontSize: 16,
    borderRadius: 5,
    marginBottom: 10,
    color: 'white',
  },
  button: {
    backgroundColor: '#0095B6',
    paddingVertical: 15,
    borderRadius: 5,
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  link: {
    color: 'white',
    marginTop: 10,
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
});

import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, TextInput, Alert } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { ref, update, remove } from 'firebase/database';
import { database } from '../firebaseConfig';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';

const screenWidth = Dimensions.get("window").width;

export default function CarDetailScreen({ route, navigation }) {
  const { car } = route.params;
  const [inspectionDate, setInspectionDate] = useState(new Date(car.inspectionDate || Date.now()));
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [editing, setEditing] = useState(false);
  const [carDetails, setCarDetails] = useState({ ...car });
  const [nextInspectionDate, setNextInspectionDate] = useState(null);
  const [marketValue, setMarketValue] = useState(null);
  const [priceTrends, setPriceTrends] = useState([10000, 10500, 11000, 12000, 12500]); // Example data

  useEffect(() => {
    calculateNextInspection(inspectionDate);
    calculateMarketValue(carDetails);
  }, [inspectionDate, carDetails]);

  const handleDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || inspectionDate;
    setShowDatePicker(false);
    setInspectionDate(currentDate);
    setCarDetails({ ...carDetails, inspectionDate: currentDate.toISOString() });
    calculateNextInspection(currentDate);
  };

  const calculateNextInspection = (date) => {
    const nextInspection = new Date(date);
    nextInspection.setMonth(nextInspection.getMonth() + 6);
    setNextInspectionDate(nextInspection.toLocaleDateString());
  };

  const calculateMarketValue = (details) => {
    const { brand, model, year, kilometer, accidentHistory } = details;
    let value = 20000; // Base value for calculation
    value -= (new Date().getFullYear() - year) * 1000;
    value -= kilometer / 10;
    if (accidentHistory === 'var') {
      value -= 5000;
    }
    setMarketValue(value);
  };

  const handleEditToggle = () => {
    setEditing(!editing);
  };

  const handleDetailChange = (field, value) => {
    setCarDetails({ ...carDetails, [field]: value });
  };

  const handleSave = async () => {
    try {
      const carRef = ref(database, `cars/${car.id}`);
      await update(carRef, carDetails);
      setEditing(false);
      Alert.alert('Başarılı', 'Araç bilgileri güncellendi');
      navigation.navigate('CarList', { updatedCar: carDetails });
    } catch (error) {
      console.error("Güncelleme hatası:", error);
      Alert.alert('Hata', 'Araç bilgileri güncellenirken bir hata oluştu');
    }
  };

  const handleDelete = async () => {
    Alert.alert(
      'Sil',
      'Bu aracı silmek istediğinizden emin misiniz?',
      [
        { text: 'İptal', style: 'cancel' },
        {
          text: 'Evet',
          onPress: async () => {
            try {
              const carRef = ref(database, `cars/${car.id}`);
              await remove(carRef);
              navigation.goBack();
              Alert.alert('Başarılı', 'Araç silindi');
            } catch (error) {
              console.error("Silme hatası:", error);
              Alert.alert('Hata', 'Araç silinirken bir hata oluştu');
            }
          },
        },
      ]
    );
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.infoContainer}>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Marka:</Text>
          {editing ? (
            <TextInput
              style={styles.input}
              value={carDetails.brand}
              onChangeText={(value) => handleDetailChange('brand', value)}
            />
          ) : (
            <Text style={styles.infoValue}>{carDetails.brand}</Text>
          )}
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Model:</Text>
          {editing ? (
            <TextInput
              style={styles.input}
              value={carDetails.model}
              onChangeText={(value) => handleDetailChange('model', value)}
            />
          ) : (
            <Text style={styles.infoValue}>{carDetails.model}</Text>
          )}
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Yıl:</Text>
          {editing ? (
            <TextInput
              style={styles.input}
              value={carDetails.year}
              onChangeText={(value) => handleDetailChange('year', value)}
            />
          ) : (
            <Text style={styles.infoValue}>{carDetails.year}</Text>
          )}
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Plaka:</Text>
          {editing ? (
            <TextInput
              style={styles.input}
              value={carDetails.plate}
              onChangeText={(value) => handleDetailChange('plate', value)}
            />
          ) : (
            <Text style={styles.infoValue}>{carDetails.plate}</Text>
          )}
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Kilometre:</Text>
          {editing ? (
            <TextInput
              style={styles.input}
              value={carDetails.kilometer}
              onChangeText={(value) => handleDetailChange('kilometer', value)}
            />
          ) : (
            <Text style={styles.infoValue}>{carDetails.kilometer}</Text>
          )}
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Fiyat:</Text>
          {editing ? (
            <TextInput
              style={styles.input}
              value={carDetails.price}
              onChangeText={(value) => handleDetailChange('price', value)}
            />
          ) : (
            <Text style={styles.infoValue}>{carDetails.price}</Text>
          )}
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Son Ekspertiz Tarihi:</Text>
          {editing ? (
            <TextInput
              style={styles.input}
              value={carDetails.lastInspectionDate}
              onChangeText={(value) => handleDetailChange('lastInspectionDate', value)}
            />
          ) : (
            <Text style={styles.infoValue}>{carDetails.lastInspectionDate}</Text>
          )}
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Kaza Geçmişi:</Text>
          {editing ? (
            <TextInput
              style={styles.input}
              value={carDetails.accidentHistory}
              onChangeText={(value) => handleDetailChange('accidentHistory', value)}
            />
          ) : (
            <Text style={styles.infoValue}>{carDetails.accidentHistory}</Text>
          )}
        </View>
      </View>

      <Text style={styles.carDescription}>{carDetails.info}</Text>

      <View style={styles.datePickerContainer}>
        <Text style={styles.datePickerLabel}>Muayene Tarihi Seç:</Text>
        <TouchableOpacity onPress={() => setShowDatePicker(true)} style={styles.datePickerButton}>
          <Text style={styles.datePickerButtonText}>
            {inspectionDate.toLocaleDateString()}
          </Text>
        </TouchableOpacity>
        {nextInspectionDate && (
          <Text style={styles.nextInspectionText}>Bir sonraki muayene tarihi: {nextInspectionDate}</Text>
        )}
      </View>

      {showDatePicker && (
        <DateTimePicker
          value={inspectionDate}
          mode="date"
          display="default"
          onChange={handleDateChange}
        />
      )}

      <View style={styles.marketValueContainer}>
        <Text style={styles.marketValueLabel}>Güncel Piyasa Değeri:</Text>
        <Text style={styles.marketValue}>₺{marketValue}</Text>
      </View>

      <View style={styles.priceTrendsContainer}>
        <Text style={styles.priceTrendsLabel}>Fiyat Trendleri:</Text>
        <LineChart
          data={{
            labels: ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs"],
            datasets: [
              {
                data: priceTrends
              }
            ]
          }}
          width={screenWidth - 40} // from react-native
          height={220}
          yAxisLabel="₺"
          chartConfig={{
            backgroundColor: "#e26a00",
            backgroundGradientFrom: "#fb8c00",
            backgroundGradientTo: "#ffa726",
            decimalPlaces: 2, // optional, defaults to 2dp
            color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
            labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
            style: {
              borderRadius: 16
            },
            propsForDots: {
              r: "6",
              strokeWidth: "2",
              stroke: "#ffa726"
            }
          }}
          bezier
          style={{
            marginVertical: 8,
            borderRadius: 16
          }}
        />
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity onPress={handleEditToggle} style={[styles.button, styles.editButton]}>
          <Text style={styles.buttonText}>{editing ? 'Vazgeç' : 'Düzenle'}</Text>
        </TouchableOpacity>
        {editing && (
          <TouchableOpacity onPress={handleSave} style={[styles.button, styles.saveButton]}>
            <Text style={styles.buttonText}>Kaydet</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity onPress={handleDelete} style={[styles.button, styles.deleteButton]}>
          <Text style={styles.buttonText}>Sil</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#ecf0f1',
  },
  infoContainer: {
    marginBottom: 20,
  },
  infoRow: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  infoLabel: {
    fontWeight: 'bold',
    marginRight: 10,
    width: 150,
  },
  infoValue: {
    flex: 1,
  },
  input: {
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  carDescription: {
    marginBottom: 20,
  },
  datePickerContainer: {
    marginBottom: 20,
  },
  datePickerLabel: {
    marginBottom: 10,
  },
  datePickerButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 5,
  },
  datePickerButtonText: {
    color: '#fff',
    textAlign: 'center',
  },
  nextInspectionText: {
    marginTop: 10,
    fontStyle: 'italic',
  },
  marketValueContainer: {
    marginBottom: 20,
    alignItems: 'center',
  },
  marketValueLabel: {
    fontWeight: 'bold',
  },
  marketValue: {
    fontSize: 24,
    color: '#FF3B30',
  },
  priceTrendsContainer: {
    marginBottom: 20,
  },
  priceTrendsLabel: {
    fontWeight: 'bold',
    marginBottom: 10,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  button: {
    flex: 1,
    marginHorizontal: 5,
    padding: 10,
    borderRadius: 5,
    borderWidth: 1,
  },
  editButton: {
    borderColor: '#007AFF',
  },
  saveButton: {
    borderColor: '#007AFF',
  },
  deleteButton: {
    borderColor: '#FF3B30',
  },
  buttonText: {
    color: 'black',
    textAlign: 'center',
  },
});

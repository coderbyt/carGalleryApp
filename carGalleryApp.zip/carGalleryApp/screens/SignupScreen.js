import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground, Alert } from 'react-native';
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
import app from '../firebaseConfig'; // Firebase yapılandırma dosyasını içe aktarın

export default function SignupScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSignup = async () => {
    if (password !== confirmPassword) {
      Alert.alert("Şifreler uyuşmuyor", "Lütfen şifreleri doğru girdiğinizden emin olun.");
      return;
    }

    try {
      const auth = getAuth();
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      console.log("Kullanıcı başarıyla kaydedildi:", userCredential.user.uid);
      navigation.navigate('Login');
    } catch (error) {
      Alert.alert("Hata", "Kayıt işlemi sırasında bir hata oluştu. Lütfen tekrar deneyin.");
      console.error("Kayıt hatası:", error);
    }
  };

  return (
    <ImageBackground
      source={{ uri: 'https://downloadwap.com/thumbs2/wallpapers/p2ls/2019/cars-transport/43/3af8242c13695363.jpg' }}
      style={styles.backgroundImage}
    >
      <View style={styles.container}>
        <View style={styles.form}>
          <Text style={styles.title}>Kaydolun ✨</Text>
          <View style={styles.line}></View>
          <Text style={styles.label}>Email:</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="Email adresinizi girin"
            placeholderTextColor="#777"
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <Text style={styles.label}>Şifre:</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            placeholder="Şifrenizi girin"
            placeholderTextColor="#777"
            secureTextEntry
          />
          <Text style={styles.label}>Şifre (Tekrar):</Text>
          <TextInput
            style={styles.input}
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            placeholder="Şifrenizi Onaylayın"
            placeholderTextColor="#777"
            secureTextEntry
          />
          <TouchableOpacity onPress={handleSignup} style={styles.button}>
            <Text style={styles.buttonText}>Kaydol</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Login')}>
            <Text style={styles.link}>Zaten hesabınız var mı? Giriş yapın</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  form: {
    backgroundColor: 'rgba(0, 0, 0, 0.0)',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 10,
    textAlign: 'center',
    marginBottom: 10,
  },
  line: {
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
    marginBottom: 10,
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
    color: 'white',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    fontSize: 16,
    borderRadius: 5,
    marginBottom: 10,
    color: 'white',
  },
  button: {
    backgroundColor: '#0095B6',
    paddingVertical: 15,
    borderRadius: 5,
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  link: {
    color: 'white',
    marginTop: 10,
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
});

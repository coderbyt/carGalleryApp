import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

export default function CarItem({ car }) {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.menuButton}
        onPress={() => navigation.navigate('CarList')}
      >
        <MaterialCommunityIcons name="car" size={30} color="#004080" />
      </TouchableOpacity>
      <View style={styles.infoContainer}>
        <Text style={styles.brand}>{car.brand}</Text>
        <Text style={styles.model}>{car.model}</Text>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('CarDetail', { car })}>
          <Text style={styles.buttonText}>İncele</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    marginVertical: 10,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  menuButton: {
    marginRight: 10, // İkon ile metin arasındaki boşluk
  },
  infoContainer: {
    flex: 1,
  },
  brand: {
    fontWeight: 'bold',
    fontSize: 20,
    marginBottom: 5,
  },
  model: {
    fontSize: 18,
    color: '#666',
    marginBottom: 10,
  },
  button: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#004080',
    paddingVertical: 7,
    paddingHorizontal: 20,
    borderRadius: 10,
  },
  buttonText: {
    color: '#004080',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 18,
  },
});
